<div class="container">
            <div class="row footer">
            
                <div class="col-md-3 col-xs-6">
                    <ul>
                    	<li><a href="index.php">Home</a></li>
                         <li><a href="model.php">Mdels</a></li>
                        
                        
                    </ul>
                </div>
                <div class="col-md-3 col-xs-6">
                   <ul>
                       <li><a href="stylist.php">Stylist</a></li>
                        <li><a href="cast.php">Cast</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-xs-6">
                   <ul>
                    	
                        <li><a href="teens.php">Teens</a></li>
                        <li><a href="photographer.php">Photographer</a></li>
                       
                    </ul>
                </div>
                <div class="col-md-3 col-xs-6">
                    <ul>
                    	 <li><a href="hostess.php">Hostess</a></li>
                         <li><a href="index.php?logout">Logout</a></li>
                         
                    </ul>
                </div>
               
                
            </div>
            
            
        </div>